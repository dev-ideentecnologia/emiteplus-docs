/**
 * @prettier
 */
const floatGenerator = () => 0.1

export default floatGenerator
